﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using CommunityToolkit.Mvvm.ComponentModel;

namespace WinUI3TimerClick.ViewModels
{
    public partial class MainViewModel : ObservableObject
    {
        // Exponemos los sub-viewmodels como propiedades
        public IncreaserViewModel ContadorVM { get; } = new();
        public TimerViewModel TimerVM { get; } = new();
    }
}
