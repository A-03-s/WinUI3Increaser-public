﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Microsoft.UI.Dispatching;
using CommunityToolkit.Mvvm.ComponentModel;
using WinUI3TimerClick.Models;

namespace WinUI3TimerClick.ViewModels
{
    public partial class TimerViewModel : ObservableObject
    {
        private readonly TimerModel _timerModel = new(60); // Empezamos en 60 segundos
        private readonly DispatcherQueueTimer _uiTimer;

        public int TiempoUI => _timerModel.SegundosRestantes;
        public string EstadoUI => _timerModel.HaTerminado ? "¡Juego Terminado!" : "Jugando...";

        public TimerViewModel()
        {
            // Inicializamos el timer que corre en el hilo de la UI de WinUI 3
            _uiTimer = DispatcherQueue.GetForCurrentThread().CreateTimer();
            _uiTimer.Interval = TimeSpan.FromSeconds(1);
            _uiTimer.Tick += OnTimerTick;
            _uiTimer.Start();
        }

        private void OnTimerTick(DispatcherQueueTimer sender, object args)
        {
            _timerModel.Decrementar();

            // Notificamos a la UI que las propiedades cambiaron
            OnPropertyChanged(nameof(TiempoUI));

            if (_timerModel.HaTerminado)
            {
                _uiTimer.Stop();
                OnPropertyChanged(nameof(EstadoUI));
            }
        }
    }
}
